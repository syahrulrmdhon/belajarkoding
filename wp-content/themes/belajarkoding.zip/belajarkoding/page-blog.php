<?php
/*
   Template Name: Blog Page
 */
 get_header();
?>




<?php get_footer();?>
